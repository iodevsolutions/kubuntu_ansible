
#ifndef X11WMMOVE_H
#define X11WMMOVE_H

#include <QWidget>

namespace Kvantum {
void X11MoveTrigger (WId wid, int x, int y);
}

#endif
